const express = require('express');

const app = express();
const port= process.env.PORT || 3000;
const customerRouter=require('./routes/customers')
app.use(express.json());
app.use('/customer', customerRouter);
app.get('/',(req,res)=>{

    res.send("Welcome...!!")
});
 


app.listen(port,()=>{
    console.log('Welcome');
});
