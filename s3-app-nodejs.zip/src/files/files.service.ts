import { Injectable } from '@nestjs/common';
import { S3 } from 'aws-sdk';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class FilesService {
  private readonly s3: S3;
  private readonly BucketName = process.env.BucketName;
  private readonly SecretAccessKey = process.env.SecretAccessKey;
  private readonly AccessKey = process.env.AccessKey;
  private readonly Region = process.env.Region;

  constructor() {
    this.s3 = new S3({
      accessKeyId: this.AccessKey,
      secretAccessKey: this.SecretAccessKey,
      region: this.Region,
    });

  }
  async getFileFromS3(keyName) {

    return await this.s3.getObject(
      { Bucket: this.BucketName, Key: keyName }
    ).promise().then((data) => {

      const fileData = data.ContentType === "application/json" ? data.Body.toString() : data.Body.toString('base64');
      return { "status": "success", "fileSize": Number(data.ContentLength / 1024).toFixed(2) + ' KB', "fileType": data.ContentType, "data": fileData };//resData;

    }).catch((error) => {
      return { "status": "err", "error": error.message }
    });

  }
  async listFiles() {

    const params = {
      Bucket: this.BucketName,
      Delimiter: '',
      Prefix: ''
    };

    const data = await this.s3.listObjects(params).promise();
    console.log(data);
let rr=[];
    for (let index = 0; index < data['Contents'].length; index++) {
      console.log(data['Contents'][index]['Key'])
      rr.push({ "name": data['Contents'][index]['Key'], "url": "https://node-s3-gk.s3.eu-north-1.amazonaws.com/" + data['Contents'][index]['Key'] }) 
    }
    console.log(rr,data);
    return { "status": "Success", "data": rr }
  }
  async uploadFile(file) {
    let s3Params = {
      Bucket: this.BucketName,
      Key: 'img/' + file.originalname,
      ACL: 'public-read',
      ContentType: file.mimetype,
      Body: file.buffer
    }
    console.log(s3Params);
    this.s3.putObject(s3Params,

      function (err, data) {
        this.s3.listObjects({ Prefix: 'img' }, function (err, data) {
          console.log(data);
        });
      });
    // upload.js



  }




}
