import { Test, TestingModule } from '@nestjs/testing';
import { FilesController } from './files.controller';
import { FilesService } from './files.service';

describe('FilesController', () => {
  let filesController: FilesController;

  beforeEach(async () => {
    const files: TestingModule = await Test.createTestingModule({
      controllers: [FilesController],
      providers: [FilesService],
    }).compile();

    filesController = files.get<FilesController>(FilesController);
  });

  describe('FilesServiceRoot', () => {
    const successResponse = {
      "response": {
        "status": "success",
        "fileSize": "0.06 KB",
        "fileType": "application/json",
        "data": "{\"name\":\"GULSHAN KUMAR\",\"email\":\"gulshan.kumar6@ibm.com\"}"
      }
    };
    const errorResponse = {
      "response": {
        "status": "err",
        "error": "Missing required key 'Bucket' in params"
      }
    };

    it('should return  "gk.json" file details', async () => {
      let response = await filesController.getFileFromS3({ keyName: "" });
      expect(response).toEqual(successResponse);
    });


    it('should return  error', async () => {
      let response = await filesController.getFileFromS3({ keyName: "gk.jsonaaa" });
      expect(response).toEqual(errorResponse);
    });


  });
});
