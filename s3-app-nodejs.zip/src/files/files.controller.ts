import { Controller, Get, Post, Query, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FilesService } from './files.service';
import { FileInterceptor } from '@nestjs/platform-express';

@Controller('files')
export class FilesController {

  constructor(private readonly appService: FilesService) { }

  @Get()
  async getFileFromS3(@Query() query) {

    let response = await this.appService.getFileFromS3(query.keyName);

    return { response };
  }

  @Get('list')
  async listFiles(@Query() query) {

    let response = await this.appService.listFiles();

    return { response };
  }


  

  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    console.log(file);   
    let response = await this.appService.uploadFile(file);
    return { response };
  }

}

