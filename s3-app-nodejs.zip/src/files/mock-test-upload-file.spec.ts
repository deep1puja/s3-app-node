import {GetObjectCommand, S3Client} from '@aws-sdk/client-s3';
import {sdkStreamMixin} from '@aws-sdk/util-stream-node';
import {mockClient} from 'aws-sdk-client-mock';
import {Readable} from 'stream';
 
import { CreateMultipartUploadCommand, UploadPartCommand } from '@aws-sdk/client-s3';
import { Upload } from "@aws-sdk/lib-storage";

const s3Mock = mockClient(S3Client);

it('mocks get object', async () => {
    // create Stream from string
    const stream = new Readable();
    stream.push('hello world');
    stream.push(null); // end of stream

    // alternatively: create Stream from file
    // const stream = createReadStream('./test/data.txt');

    // wrap the Stream with SDK mixin
    const sdkStream = sdkStreamMixin(stream);

    s3Mock.on(GetObjectCommand).resolves({Body: sdkStream});

    const s3 = new S3Client({});

    const getObjectResult = await s3.send(new GetObjectCommand({Bucket: '', Key: ''}));

    const str = await getObjectResult.Body?.transformToString();

    expect(str).toBe('hello world');
});
 

s3Mock.on(CreateMultipartUploadCommand).resolves({ UploadId: '1' });
s3Mock.on(UploadPartCommand).resolves({ ETag: '1' });

const s3Upload = new Upload({
    client: new S3Client({}),
    params: {
        Bucket: 'mock',
        Key: 'test',
        Body: 'x'.repeat(6 * 1024 * 1024), // 6 MB
    },
});

s3Upload.on('httpUploadProgress', (progress) => {
    console.log(progress);
});

  s3Upload.done();