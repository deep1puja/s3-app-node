import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { FilesModule } from './files/files.module';
import { ConfigModule } from '@nestjs/config';
 
@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true, envFilePath :'.env'}), FilesModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
